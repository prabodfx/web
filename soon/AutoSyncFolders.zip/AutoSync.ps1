# One-way copy script - No deletions ever
$source = "C:\FolderA"  # Change to your source folder
$destination = "C:\FolderB"  # Change to your destination folder

# Create folders if they don't exist
if (!(Test-Path $source)) { New-Item -ItemType Directory -Path $source -Force }
if (!(Test-Path $destination)) { New-Item -ItemType Directory -Path $destination -Force }

# Continuous monitoring loop
Write-Host "Starting one-way sync from $source to $destination"
Write-Host "Press Ctrl+C to stop"

while ($true) {
    try {
        # Copy only NEW or MODIFIED files (never delete anything)
        # /XO excludes older files, /E includes subfolders
        # /R:3 retry 3 times on failure, /W:1 wait 1 second between retries
        # /NP no progress, /NJH no job header, /NJS no job summary
        robocopy $source $destination /E /XO /R:3 /W:1 /NP /NJH /NJS
        
        # Or use PowerShell copy (alternative to robocopy)
        # Get-ChildItem -Path $source -Recurse | ForEach-Object {
        #     $destPath = Join-Path $destination $_.FullName.Substring($source.Length)
        #     if (!(Test-Path $destPath) -or ($_.LastWriteTime -gt (Get-Item $destPath).LastWriteTime)) {
        #         Copy-Item $_.FullName -Destination $destPath -Force
        #     }
        # }
        
        Start-Sleep -Seconds 2  # Check every 2 seconds
    }
    catch {
        Write-Host "Error: $_" -ForegroundColor Red
        Start-Sleep -Seconds 5
    }
}